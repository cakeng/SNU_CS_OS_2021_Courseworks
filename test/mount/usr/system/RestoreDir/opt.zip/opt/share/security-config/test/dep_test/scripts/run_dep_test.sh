#!/bin/sh
#=========================================================
# [Includes]
#=========================================================
. "/opt/share/security-config/test/utils/_sh_util_lib"
#=========================================================
# Script Begin
#=========================================================
echoI "Script Begin"
#=========================================================
# [Variable]
#=========================================================
PATH=/bin:/usr/bin:/sbin:/usr/sbin
log_file="$dep_script_dir/log.csv"
result_file="$dep_script_dir/result"
fail_cnt=
exception_list="$dep_script_dir/exception.list"
function getExecstack {
	$FIND /usr /etc /opt -perm +111 | $XARGS $utils_dir/file | grep "ELF" | cut -d ":" -f1 | xargs $utils_dir/execstack -q | grep "^X " | cut -d " " -f2 > $log_file
	fail_cnt=`cat $log_file | wc -l`
}

#=========================================================
# [01] Delete previous result and set utils
#=========================================================
$RM $log_file
$TOUCH $log_file
$RM $result_file
$TOUCH $result_file

# Rename utils
file_cmd=`$FIND $utils_dir -name file*`
execstack_cmd=`$FIND $utils_dir -name execstack*`
if [ "$file_cmd" != "" ]; then
    $MV $file_cmd $utils_dir/file
fi

#set required so
LIBELF="libelf-0.153.so"
LIBELF_LN="libelf.so.0"
lib_dir=
arch_info=`$utils_dir/file $utils_dir/file`
if [[ $arch_info == *"aarch64"* ]]
then
    echo "aarch64!!"
    arch="aarch64"
	lib_dir="/usr/lib64"
elif [[ $arch_info == *"ARM"* ]]
then
    echo "arm!!"
    arch="arm"
	lib_dir="/usr/lib"
elif [[ $arch_info == *"x86-64"* ]]
then
    echo "x86_64!!"
    arch="x86_64"
	lib_dir="/usr/lib64"
elif [[ $arch_info == *"Intel"* ]]
then
    echo "i386!!"
    arch="i386"
	lib_dir="/usr/lib"
fi

if [ "$execstack_cmd" != "" ]; then
	$MV $execstack_cmd $utils_dir/execstack
	ln -s $lib_dir/$LIBELF $lib_dir/$LIBELF_LN
fi

#=========================================================
# [02] Run test
#=========================================================
echoI "Get Execstack"

getExecstack
echo "================================================================"
if [ $((fail_cnt)) -lt 1 ]; then
	echo "NO STACK RWE"
	echo "YES" > $result_file
	$RM $log_file
else
	echo "STACK RWE: $((fail_cnt))"
	echo "NO" > $result_file
fi
echo "================================================================"
echo ""

if [ ! -d $log_dir ]; then
    echo "make log dir"
    $MKDIR $log_dir
else
    echo "log dir exist"
fi
if [ ! -d $result_dir ]; then
    echo "make result dir"
    $MKDIR $result_dir
else
    echo "result dir exist"
fi
if [ -a $dep_script_dir/log.csv ]; then
	$MV $dep_script_dir/log.csv $log_dir/dep_test.log
fi
$MV $dep_script_dir/result $result_dir/dep_test.result
if [ -a $lib_dir/$LIBELF_LN ]; then
	rm $lib_dir/$LIBELF_LN
fi
fnPrintSDone
