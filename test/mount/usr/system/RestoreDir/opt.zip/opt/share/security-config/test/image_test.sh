#!/bin/bash

PATH=/bin:/usr/bin:/sbin:/usr/sbin
security_test_path="/opt/share/security-config/test"
log_path="/opt/share/security-config/log"
log_file="$log_path/image_test_log"

# This script is running automatically at the time of image build.

# Init log
if [ -e "$log_file" ]
then
	rm $log_file
fi

# ASLR test for all excutable files
#aslr_test="$security_test_path/aslr_test/scripts/run_aslr_test.sh"
aslr_test="$security_test_path/aslr_test/scripts/run_aslr_test_all_files.sh"
aslr_log="$log_path/aslr_not_applied_files"
if [ -e  $aslr_test ]
then
	$aslr_test 1>/dev/null 2>/dev/null
	if [ -e "$aslr_log" ]
	then
		echo "###### ASLR not applied list ######" >> $log_file
		cat $aslr_log >> $log_file
	fi
fi

# DEP test
dep_test="$security_test_path/dep_test/scripts/run_dep_test.sh"
dep_log="$log_path/dep_test.log"
if [ -e  $dep_test ]
then
	$dep_test 1>/dev/null 2>/dev/null
	if [ -e "$dep_log" ]
	then
		echo "###### DEP not applied list ######" >> $log_file
		cat $dep_log >> $log_file
	fi
fi

# PATH test
path_check_test="$security_test_path/path_check_test/path_check.sh"
path_log="$log_path/path_check.log"
if [ -e  $path_check_test ]
then
	$path_check_test 1>/dev/null 2>/dev/null
	if [ -e "$path_log" ]
	then
		echo "###### path check error list ######" >> $log_file
		cat $path_log >> $log_file
	fi
fi

# capability test
check_new_capability_test="$security_test_path/capability_test/check_new_capabilities.sh"
check_new_capability_log="$log_path/check_new_capabilities.log"
if [ -e  $check_new_capability_test ]
then
	$check_new_capability_test 1>/dev/null 2>/dev/null
	if [ -e "$check_new_capability_log" ]
	then
		echo "###### new capabilites list ######" >> $log_file
		cat $check_new_capability_log >> $log_file
	fi
fi

# new service test
new_service_test="$security_test_path/new_service_test/check_new_service.sh"
new_service_log="$log_path/new_service.log"
if [ -e  $new_service_test ]
then
	$new_service_test 1>/dev/null 2>/dev/null
	if [ -e "$new_service_log" ]
	then
		echo "###### not permitted service list ######" >> $log_file
		cat $new_service_log >> $log_file
	fi
fi

# Print the failed lists in build log
if [ -e "$log_file" ]
then
	cat $log_file
fi

