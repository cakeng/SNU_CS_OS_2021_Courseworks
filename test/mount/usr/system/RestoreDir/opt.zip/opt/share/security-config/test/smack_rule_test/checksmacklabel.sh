#!/bin/bash

PATH=/bin:/usr/bin:/sbin:/usr/sbin
result_dir="/opt/share/security-config/result"
log_dir="/opt/share/security-config/log"
result_file=$result_dir"/checksmacklabel.result"
log_file=$log_dir"/checksmacklabel.log"
exception_file="/opt/share/security-config/test/smack_rule_test/smacklabel_exception.list"

function CHECK_EXCEPTION
{
	while read exception_line
	do
		filtered_label=$(echo $label | grep $exception_line)
		if [ -n "$filtered_label" ]
		then
			return 1
		fi
	done < <(cat $exception_file ) 
	return 0
}

function CHECK_RULE_ACCESS
{
	access_label=$(echo "${label:8}" | rev | cut -c 2- | rev)
	if [ "$access_label" != '_' ] && [ "$access_label" != '*' ] && [ "$access_label"  != '^' ] &&
	   [ "$access_label" != 'System' ] && [ "$access_label" != 'System::Run' ] && [ "$access_label" != 'System::Log' ] &&
	   [ "$access_label" != 'System::Shared' ] && [ "$access_label" != 'User' ] && [ "$access_label" != 'User::Home' ] &&
	   [ "$access_label" != 'User::App::Shared' ] && [ "$access_label" != 'System::Privileged' ] &&
	   [ "$access_label" != 'User::Shell' ] && [ "${access_label:0:11}" != 'User::Pkg::' ] && [ "${access_label:0:14}" != 'User::Author::' ]
	then
		CHECK_EXCEPTION
		if [ "$?" == 0 ]
		then
			echo "ACCESS label,$line2" >> $log_file
		fi
	fi
}

function CHECK_RULE_EXECUTE
{
	execute_label=$(echo "${label:9}" | rev | cut -c 2- | rev)
	if [ "$execute_label"  != '_' ] && [ "$execute_label"  != '^' ] && [ "$execute_label"  != 'System' ] && [ "$execute_label"  != 'User' ] &&
           [ "$execute_label" != 'System::Privileged' ] && [ "$execute_label"  != 'User::Shell' ] && [ "${execute_label:0:9}"  != 'User::Pkg' ]
	then
		CHECK_EXCEPTION
		if [ "$?" == 0 ]
		then
			echo "EXECUTE label,$line2" >> $log_file
		fi
	fi
}

function LABEL_CHECK
{    
	chsmack $1/* | while read line2 
	do
		label=$(echo $line2 | rev | cut -f1 -d " " | rev)
		cutted_label=${label:0:3}
		if [ "$cutted_label" == 'acc' ]
		then
			CHECK_RULE_ACCESS
		elif [ "$cutted_label" == 'exe' ] 
		then
			CHECK_RULE_EXECUTE
			label=$(echo $line2 | rev | cut -f2 -d " " | rev)
			CHECK_RULE_ACCESS
		elif [ "$cutted_label" == 'tra' ] 
		then
			label=$(echo $line2 | rev | cut -f2 -d " " | rev)
			cutted_label=${label:0:3}
			if [ "$cutted_label" == 'acc' ]
			then
				CHECK_RULE_ACCESS
			elif [ "$cutted_label" == 'exe' ] 
			then
				CHECK_RULE_EXECUTE
				label=$(echo $line2 | rev | cut -f3 -d " " | rev)
				CHECK_RULE_ACCESS	
			fi	     
		fi
	done
	chsmack $1/.* | while read line2 
	do
		label=$(echo $line2 | rev | cut -f1 -d " " | rev)
		cutted_label=${label:0:3}
		if [ "$cutted_label" == 'acc' ]
		then
			CHECK_RULE_ACCESS
		elif [ "$cutted_label" == 'exe' ] 
		then
			CHECK_RULE_EXECUTE
			label=$(echo $line2 | rev | cut -f2 -d " " | rev)
			CHECK_RULE_ACCESS
		elif [ "$cutted_label" == 'tra' ] 
		then
			label=$(echo $line2 | rev | cut -f2 -d " " | rev)
			cutted_label=${label:0:3}
			if [ "$cutted_label" == 'acc' ]
			then
				CHECK_RULE_ACCESS
			elif [ "$cutted_label" == 'exe' ] 
			then
				CHECK_RULE_EXECUTE
				label=$(echo $line2 | rev | cut -f3 -d " " | rev)
				CHECK_RULE_ACCESS	
			fi	     
		fi
	done
}

function SMACK_LABEL_CHECK
{
	find / -type d 2>/dev/null | while read line  # Remove error print
	do
		LABEL_CHECK $line 
	done
}

if [ ! -d $log_dir ]; then
	mkdir $log_dir
fi
if [ ! -d $result_dir ]; then
	mkdir $result_dir
fi

if [ -e $result_file ]
then
	rm $result_file
fi
if [ -e $log_file ]
then
	rm $log_file
fi

echo "SMACK LABEL CHECK STARTED!"

SMACK_LABEL_CHECK 

if [ ! -e $log_file ]
then
	echo "YES" >> $result_file
else
	echo "NO" >> $result_file
fi

echo "SMACK LABEL CHECK FINISHED!"
