#!/bin/bash

PATH="/usr/bin:/bin:/usr/sbin:/sbin"
utl_path="/opt/share/security-config/test/utils"
log_file="/opt/share/security-config/log/aslr_not_applied_files"
exception_path="/opt/share/security-config/test/aslr_test/scripts/aslr_exception.list"

# Check whether this file is one of exception lists.
# args : $1 = file path
function CHECK_EXCEPTION
{
	temp=$(cat $exception_path | grep $1)
	if [ -n "$temp" ]
	then
		echo "find exception" "$1"
		return 1
	fi
	return 0
}

# Rename file util
file_cmd=`find $utl_path -name file.*`
if [ "$file_cmd" != "" ]; then
	/bin/mv $file_cmd $utl_path/file
fi

#init log
if [ -e "$log_file" ]
then
	/usr/bin/rm $log_file
fi

/usr/bin/echo "Start aslr check test"

/usr/bin/find / -type f -executable 2>/dev/null | /usr/bin/xargs $utl_path/file | /usr/bin/grep "executable" | /usr/bin/grep -v "script" | /usr/bin/cut -d ":" -f1 >> $log_file

# Retrieve exec permission (chmod & cat need to be considered separately to finish below lines)
# Checking "/etc/smack/onlycap" is temporary. This should be considered again later.
while read log_file_line
do
	if [ -e "/etc/smack/onlycap" ] && [ $log_file_line != "/usr/bin/chmod" ] && [ $log_file_line != "/usr/bin/cat" ] && [ $log_file_line != "/usr/bin/qemu-arm" ]
	then
		CHECK_EXCEPTION $log_file_line
		if [ "$?" == 0 ]
		then
			chmod a-x $log_file_line		
		fi
	fi
done < <(cat $log_file)

/usr/bin/echo "Finish aslr check test"
