#!/bin/bash

PATH=/bin:/usr/bin:/sbin:/usr/sbin
exception_list_path="/opt/share/security-config/test/capability_test/new_capabilities_exception.list"
result_file="/opt/share/security-config/result/check_new_capabilities.result"
log_file="/opt/share/security-config/log/check_new_capabilities.log"
get_cap_tmp_path="/opt/share/security-config/test/capability_test/get_cap.list"

# check exception
# args : $1 = getcap result
function check_exception
{
	check_result=$(/usr/bin/cat $exception_list_path | grep "$1")
	if [ "$check_result" = "" ] # This seems newly added capability. Add to log file.
	then		
		echo "$1" >> $log_file
	fi
}

# init result and log
echo "Run verify capabilities test"
if [ -e "$log_file" ]
then
	rm $log_file
fi
if [ -e "$result_file" ]
then
	rm $result_file
fi

# list capabilities
/usr/sbin/getcap / -r 2>/dev/null >> $get_cap_tmp_path
while read line
do
	check_exception "$line"
done < <(/usr/bin/cat $get_cap_tmp_path)

if [ -e $get_cap_tmp_path ]
then
	rm $get_cap_tmp_path
fi
if [ ! -e $log_file ]
then
	echo "YES" > $result_file
else
	echo "NO" > $result_file
fi

