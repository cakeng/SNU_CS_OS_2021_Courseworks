#!/bin/sh
PATH=/bin:/usr/bin:/sbin:/usr/sbin

#--------------------------------------
#   network log dump
#--------------------------------------

# not allow to use relative path
if [[ $0 == "/"* ]]; then
	echo "Absolute path"
else
	echo "Relative path"
	exit -1
fi

export DISPLAY=:0.0
NETWORK_DATA_DIR=/opt/usr/data/network

NOWTIME=$(date +"%m-%d-%Y(%T)")
FILENAME="network_file_log_$NOWTIME.tar.gz"

/usr/bin/tar -czf ${NETWORK_DATA_DIR}/$FILENAME -C ${NETWORK_DATA_DIR} .
