#!/bin/sh
PATH=/bin:/usr/bin:/sbin:/usr/sbin

#--------------------------------------
#   network dump
#--------------------------------------

# not allow to use relative path
if [[ $0 == "/"* ]]; then
	echo "Absolute path"
else
	echo "Relative path"
	exit -1
fi

export DISPLAY=:0.0
NETWORK_DATA_DIR=/opt/usr/data/network
NETWORK_DEBUG=$1/network

@BIN_DIR@/mkdir -p ${NETWORK_DEBUG}

@BIN_DIR@/netstat -na > ${NETWORK_DEBUG}/netstat
@SBIN_DIR@/route -n > ${NETWORK_DEBUG}/route
@SBIN_DIR@/route -A inet6 -n > ${NETWORK_DEBUG}/route6
@BIN_DIR@/cat /proc/net/wireless > ${NETWORK_DEBUG}/wireless
@BIN_DIR@/cat /etc/resolv.conf > ${NETWORK_DEBUG}/resolv.conf
@SBIN_DIR@/ifconfig -a > ${NETWORK_DEBUG}/ifconfig
/usr/sbin/iptables -L > ${NETWORK_DEBUG}/iptables
/usr/sbin/ip6tables -L > ${NETWORK_DEBUG}/ip6tables
@BIN_DIR@/cat /proc/net/tcp > ${NETWORK_DEBUG}/tcp
@BIN_DIR@/cat /proc/net/tcp6 > ${NETWORK_DEBUG}/tcp6
@BIN_DIR@/cat /proc/net/route > ${NETWORK_DEBUG}/proc_route
@SBIN_DIR@/ip -4 rule > ${NETWORK_DEBUG}/ip4_rule
@SBIN_DIR@/ip -6 rule > ${NETWORK_DEBUG}/ip6_rule
@SBIN_DIR@/ip -4 route show table all > ${NETWORK_DEBUG}/ip4_route
@SBIN_DIR@/ip -6 route show table all > ${NETWORK_DEBUG}/ip6_route
/usr/bin/vconftool -r get memory/dnet >> ${NETWORK_DEBUG}/status
/usr/bin/vconftool -r get memory/wifi >> ${NETWORK_DEBUG}/status
/usr/bin/vconftool -r get file/private/wifi >> ${NETWORK_DEBUG}/status
/usr/bin/vconftool -r get db/wifi >> ${NETWORK_DEBUG}/status
@BIN_DIR@/mv ${NETWORK_DATA_DIR}/tcpdump*.pcap* ${NETWORK_DEBUG}
@BIN_DIR@/tar -czf ${NETWORK_DEBUG}/network_file_log.tar.gz -C ${NETWORK_DATA_DIR} .
