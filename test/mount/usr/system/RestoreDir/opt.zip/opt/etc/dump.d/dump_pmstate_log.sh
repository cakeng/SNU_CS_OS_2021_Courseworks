#!/bin/sh
#
# Dump PM state log
#
PATH=/bin:/usr/bin:/sbin:/usr/sbin

/usr/bin/devicectl display savelog
