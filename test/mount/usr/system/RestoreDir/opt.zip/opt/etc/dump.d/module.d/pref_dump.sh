#!/bin/sh

PREF_DUMP=$1/pref
/bin/mkdir -p $PREF_DUMP

for file in `/usr/bin/find /opt/usr/apps/ -name *.pref`
do
	chsmack $file >> $PREF_DUMP/pref_value
	chsmack $file/* >> $PREF_DUMP/pref_value
	ls -alZ $file >> $PREF_DUMP/pref_value
	PKG_ID=`echo "$file" | awk -F'/' '{print $5}'`
	/usr/bin/preference_tool get $PKG_ID >> $PREF_DUMP/pref_value
	mkdir -p $PREF_DUMP/$PKG_ID
	cp -rf --preserve=all $file/* $PREF_DUMP/$PKG_ID
	echo "===============================================" >> $PREF_DUMP/pref_value
done
