#!/bin/sh

#--------------------------------------
#    Factory-reset
#--------------------------------------
FACTORY_RESET_DEBUG=$1/factory-reset
/bin/mkdir -p  ${FACTORY_RESET_DEBUG}
/bin/tar -cvf ${FACTORY_RESET_DEBUG}/factory-reset-log.tar /opt/.factoryreset*

