#!/bin/bash

CMD=$1

if [ -z $CMD ]; then
	echo "argument error : 1st arg is cmd (msg/del) "
	echo "usage-1) ./remove-keys.sh msg"
	echo "usage-2) ./remove-keys.sh del"
	echo "usage-3) ./remove-keys.sh --> Error case"
	exit 1
fi

buxton2ctl -d list-keys memory | sort > /opt/usr/bk_memory.txt
buxton2ctl -d list-keys system | sort > /opt/usr/bk_system.txt

MSG="[WARNING] CALLING VCONFTOOL OUTSIDE OF VCONF-INTERNAL-KEYS IS NOT ALLOWED."
list1=`comm -13 /opt/usr/vk_memory.txt /opt/usr/bk_memory.txt`



for file in $list1
do
if [ $CMD == "msg" ]; then
	echo "$MSG ($file)"
elif [ $CMD == "del" ]; then
	buxton2ctl -d -i unset memory $file
fi
done

list2=`comm -13 /opt/usr/vk_system.txt /opt/usr/bk_system.txt`
for file in $list2
do
if [ $CMD == "msg" ]; then
	echo "$MSG ($file)"
elif [ $CMD == "del" ]; then
	buxton2ctl -d -i unset system $file
fi
done

buxton2ctl remove-garbage-data system
